module.exports = {
  safari: "tp",
};
