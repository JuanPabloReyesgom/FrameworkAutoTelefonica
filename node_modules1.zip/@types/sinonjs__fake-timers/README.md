# Installation
> `npm install --save @types/sinonjs__fake-timers`

# Summary
This package contains type definitions for @sinonjs/fake-timers (https://github.com/sinonjs/fake-timers).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/sinonjs__fake-timers.

### Additional Details
 * Last updated: Tue, 06 Jul 2021 16:34:53 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Wim Looman](https://github.com/Nemo157), [Josh Goldberg](https://github.com/joshuakgoldberg), [Rogier Schouten](https://github.com/rogierschouten), [Yishai Zehavi](https://github.com/zyishai), and [Remco Haszing](https://github.com/remcohaszing).
