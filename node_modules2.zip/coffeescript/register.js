require('./lib/coffee-script/register');
