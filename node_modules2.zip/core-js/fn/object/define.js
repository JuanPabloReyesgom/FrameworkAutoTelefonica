require('../../modules/core.object.define');
module.exports = require('../../modules/_core').Object.define;
