require('../../modules/es6.string.big');
module.exports = require('../../modules/_core').String.big;
