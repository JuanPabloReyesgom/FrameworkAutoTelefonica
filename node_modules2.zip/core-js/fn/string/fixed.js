require('../../modules/es6.string.fixed');
module.exports = require('../../modules/_core').String.fixed;
