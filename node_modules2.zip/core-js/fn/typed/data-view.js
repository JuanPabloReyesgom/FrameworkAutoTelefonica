require('../../modules/es6.typed.data-view');
require('../../modules/es6.object.to-string');
module.exports = require('../../modules/_core').DataView;
