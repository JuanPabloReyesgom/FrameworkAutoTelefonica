require('../../modules/es7.math.imulh');
module.exports = require('../../modules/_core').Math.imulh;
