require('../../modules/es7.symbol.observable');
module.exports = require('../../modules/_wks-ext').f('observable');
