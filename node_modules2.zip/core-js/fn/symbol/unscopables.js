module.exports = require('../../modules/_wks-ext').f('unscopables');
