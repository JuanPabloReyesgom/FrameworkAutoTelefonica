module.exports = require('./baz.coffee')(5)
