module.exports = require('./baz.litcoffee')(5)
